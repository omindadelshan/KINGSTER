from StreamMusic.function.admins import admins
from StreamMusic.function.admins import get
from StreamMusic.function.admins import set

__all__ = ["set", "get", "admins"]
